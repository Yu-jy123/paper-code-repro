# Trajectory information validity across 20 intersections

Reproduction code for **Validity horizons of vehicle trajectory information across 20 urban intersections**.

## Data and code are separate resources

The original Songdo Traffic dataset is provided by Fonod, Cho, Yeo and Geroliminis at https://doi.org/10.5281/zenodo.13828384 under CC BY 4.0. That DOI identifies the source dataset. It does not archive the analysis or plotting code in this repository.

This repository contains the study-specific download, preprocessing, analysis, audit, plotting and table/manuscript-generation scripts. The raw CSV data and per-origin caches are not redistributed here. The downloader retrieves the selected source files from Zenodo. The included source provenance records preserve the expected checksums. Source documentation and its licence are retained in `sources/`; the data licence does not automatically license the study-specific code.

## Study sample

The sample includes 80 files: all 20 available intersections, 4 and 7 October 2022, and AM1 and PM1 on each date. It contains 56,298,156 original records and produces 1,598,746 eligible replay origins. These are observations from one city, not a cross-city validation. The deterministic sampling and analysis settings are documented in `protocol.json`.

## Reproduce all figures and tables

Use Python 3.12 and install the dependencies in a virtual environment:

```
python -m pip install -r requirements.txt
python fetch_songdo.py
python analyze_songdo.py
python audit_results.py
python plot_results.py
python build_manuscripts.py
```

Run the commands from this repository directory. Downloading requires network access and several gigabytes of disk space. Full raw-data analysis can take substantial time and memory. Scripts use paths relative to their own location. Local `packages` fallback paths are optional and are not needed when the requirements are installed normally.

For figure regeneration alone, the committed `results/` tables allow `python plot_results.py` to run without downloading the raw data. The committed result tables also allow `python build_manuscripts.py` to generate the original English and Chinese manuscript versions, including the seven tables. This builder preserves the original availability paragraph; a later submission-specific repository-link edit is not part of the scientific calculation.

### Script responsibilities

- `fetch_songdo.py`: fetch the 80 selected CSV members; retain provenance and SHA-256 checksums.
- `analyze_songdo.py`: clean trajectories, construct causal prediction histories, calculate four predictor errors, calibrate the three horizon rules, and produce site-level and summary result tables.
- `audit_results.py`: verify raw-file hashes, independently check selected raw trajectory windows, and produce period-level summaries.
- `plot_results.py`: produce Figures 1–5 from the numerical result tables.
- `build_manuscripts.py`: generate Tables 1–7 and assemble the original manuscript from computed results.

`figures/` contains reference PNG and PDF figures. `results/` contains the full numerical outputs, including site-level failures and audit results. `SHA256SUMS.json` records checksums for this code-package snapshot. It is not a source-data DOI or a repository publication record.

## Interpretation and limitations

Calibration uses the earlier date at the other 19 sites. Testing uses the later date at each held-out site. Unknown follow-up is retained in exceedance bounds. Bootstrap intervals are descriptive and conditional on fitted rules. They are not formal guarantees under spatial dependence. Controlled position offsets are imposed sensitivity scenarios, not measured localisation errors. Synthetic arrays are used only in numerical unit checks and never enter empirical results.

The authors should cite the actual public GitHub repository URL after publication of this code package. No repository URL is asserted by this local package.
