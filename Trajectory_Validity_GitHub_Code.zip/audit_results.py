"""Independent numerical audit of saved empirical results."""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from analyze_songdo import ROOT,RES,CACHE,RAW,SITES,curves,calibrate,metrics,sample
def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
data=[];aud=[]
for p in sorted(RAW.glob('*.csv')):
    provenance=json.loads(p.with_suffix('.csv.provenance.json').read_text())
    assert p.stat().st_size==provenance['local_size_bytes']
    assert digest(p)==provenance['local_sha256']
    ar=dict(np.load(CACHE/(p.stem+'.npz')))
    date,site,period=p.stem.split('_');ar.update(date=date,site=site,period=period)
    data.append(ar)
    n=len(ar['state']);assert ar['first'].shape==(n,4,3)
    assert np.all(np.diff(ar['first'].astype(int),axis=2)>=0)
    assert np.all((ar['nfollow']>=1)&(ar['nfollow']<=30))
    assert np.all((ar['first']==31)|(ar['first']<=ar['nfollow'][:,None,None]))
    assert np.sum(ar['nfollow']==30)==int(ar['nfull'])
    aud.append({'file':p.name,'sha256_verified':True,'origins':n})
assert len(data)==80
cal=[a for a in data if a['date']=='2022-10-04'];test=[a for a in data if a['date']=='2022-10-07']
cc,_=curves(cal,'primary',1,1)
periods=[]
for a in test:
    state,first,nf=sample(a,'primary',1,1)
    for rule in ['global','state','worst_site']:
        tau=calibrate(cc,a['site'],rule)
        periods.append(dict(site=a['site'],period=a['period'],rule=rule,**metrics(state,first,nf,tau)))
pd.DataFrame(periods).to_csv(RES/'period_metrics.csv',index=False)
orig=pd.read_csv(RES/'site_metrics.csv');assert (orig.lower<=orig.upper+1e-12).all();assert ((orig.upper<=1)&(orig.lower>=0)).all()
assert (orig[orig.population=='full'].unknown==0).all()
# Independent single-window calculation from raw observations, not vectorized fit.
df=pd.read_csv(RAW/'2022-10-04_A_AM1.csv')
df=df[df.Vehicle_Class==0]
verified=0
for vid,g in df.groupby('Vehicle_ID'):
    if len(g)<300:continue
    t=pd.to_timedelta(g.Local_Time).dt.total_seconds().to_numpy();p=g[['Local_X','Local_Y']].to_numpy()
    if np.any(np.diff(t)<=0) or np.any(np.diff(t)>.1):continue
    u=t[np.searchsorted(t,t[0]+1.5)];idx=np.searchsorted(t,np.arange(-10,1)*.1+u+1e-8,side='right')-1
    s=t[idx]-u;y=p[idx]-p[np.searchsorted(t,u)]
    vel=np.linalg.lstsq(s[:,None],y,rcond=None)[0][0]
    er=[]
    for h in np.arange(1,31)*.1:
        if u+h>t[-1]:break
        ref=np.array([np.interp(u+h,t,p[:,k]) for k in range(2)])
        er.append(np.linalg.norm(p[np.searchsorted(t,u)]+h*vel-ref))
    # Match t0 independently; multiple cars can share a t0, so use the error match.
    ar=next(a for a in data if a['date']=='2022-10-04' and a['site']=='A' and a['period']=='AM1')
    rows=np.flatnonzero(np.isclose(ar['t0'],u,atol=1e-8,rtol=0))
    assert any(np.isclose(ar['err1'][r,1],er[9],atol=2e-6) for r in rows)
    verified+=1
    if verified==10:break
assert verified==10
out={'raw_files_verified':len(aud),'origins':sum(a['origins'] for a in aud),'independent_raw_window_checks':verified,'threshold_monotonicity':True,'bounds_valid':True,'complete_population_unknown_zero':True,'files':aud}
(RES/'audit.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('AUDIT PASSED',out['raw_files_verified'],out['origins'],flush=True)
