# **Songdo Traffic: High Accuracy Georeferenced Vehicle Trajectories from a Large-Scale Study in a Smart City**

**License:** Creative Commons Attribution 4.0 International (CC BY 4.0)  
**Creators:** Robert Fonod¹, Haechan Cho², Hwasoo Yeo², Nikolas Geroliminis¹

1. **EPFL** (École Polytechnique Fédérale de Lausanne), Switzerland
2. **KAIST** (Korea Advanced Institute of Science and Technology), South Korea

## **Overview**  
The **Songdo Traffic** dataset delivers **precisely georeferenced vehicle trajectories** captured through **high-altitude bird's-eye view (BeV) drone footage** over **Songdo International Business District, South Korea**. Comprising **approximately 700,000 unique trajectories**, this resource represents one of the most extensive aerial traffic datasets publicly available, distinguishing itself through **exceptional temporal resolution** that captures vehicle movements at **29.97 points per second**, enabling unprecedented granularity for advanced urban mobility analysis.

## **Dataset Composition**  
The dataset consists of four primary components:

- **Trajectory Data**: 80 ZIP archives containing high-resolution vehicle trajectories with georeferenced positions, speeds and acceleration profiles, and other metadata.
- **Orthophoto Cut-Outs**: High-resolution (8000×8000 pixel) orthophoto images for each monitored intersection, used for georeferencing and visualization.
- **Road and Lane Segmentations**: CSV files defining lane polygons within road sections, facilitating mapping of vehicle positions to road segments and lanes.
- **Sample Videos**: A selection of 4K UHD drone video samples capturing intersection footage during the experiment.

## **Data Collection**  
The dataset was collected as part of a **collaborative multi-drone experiment** conducted by **KAIST and EPFL** in **Songdo, South Korea**, from **October 4–7, 2022**.

- **A fleet of 10 drones** monitored **20 busy intersections**, executing advanced flight plans to optimize coverage.  
- **4K (3840×2160) RGB video footage** was recorded at **29.97 FPS** from altitudes of **140–150 meters**.  
- Each drone **flew 10 sessions per day**, covering peak morning and afternoon periods.  
- The experiment resulted in **12TB of 4K raw video data**.  

More details on the **experimental setup and data processing pipeline** are available in **[[1]](https://arxiv.org/abs/2411.02136)**.

## **Data Processing**
The trajectories were extracted using **[geo-trax](https://github.com/rfonod/geo-trax)**, an **advanced deep learning framework** designed for **high-altitude UAV-based traffic monitoring**. This state-of-the-art pipeline integrates **vehicle detection, tracking, trajectory stabilization, and georeferencing** to extract high-accuracy traffic data from drone footage.  

#### **Key Processing Steps:**  
1. **Vehicle Detection & Tracking:** Vehicles were detected and tracked across frames using a deep learning-based detector and motion-model-based tracking algorithm.  
2. **Trajectory Stabilization:** A novel track stabilization method was applied using detected vehicle bounding boxes as exclusion masks in image registration.  
3. **Georeferencing & Coordinate Transformation:** Each trajectory was transformed into **global (WGS84), local Cartesian, and orthophoto coordinate systems**.  
4. **Vehicle Metadata Estimation:** In addition to time-stamped vehicle trajectories, various metadata attributes were also extracted, including **vehicle dimensions and type, speed, acceleration, class, lane number, road section, and visibility status**.

More details on the **extraction methodology** are available in **[[1]](https://arxiv.org/abs/2411.02136)**.

## **File Structure & Formats**  

#### **1. Trajectory Data (Daily Intersection ZIPs, 16.2 MB ~ 360.2 MB)**  
The trajectory data is organized into **80 ZIP files**, each containing traffic data for a **specific intersection and day** of the experiment.

**File Naming Convention:**  
```plaintext
YYYY-MM-DD_intersectionID.zip
```
- `YYYY-MM-DD` represents the **date** of data collection (2022-10-04 to 2022-10-07).
- `intersectionID` is a unique identifier for one of the **20 intersections** where data was collected (A, B, C, E, …, U). The letter D is reserved to denote "Drone". 

Each ZIP file contains **10 CSV files**, each corresponding to an **individual flight session**:
```
YYYY-MM-DD_intersectionID.zip
│── YYYY-MM-DD_intersectionID_AM1.csv
├── …
│── YYYY-MM-DD_intersectionID_AM5.csv
│── YYYY-MM-DD_intersectionID_PM1.csv
├── …
└── YYYY-MM-DD_intersectionID_PM5.csv
```

Here, **AM1-AM5** and **PM1-PM5** denote **morning** and **afternoon** flight sessions, respectively. For example, `2022-10-04_S_AM1.csv` contains all extracted trajectories from the first morning session of the first day at the intersection 'S'.

**CSV File Example Structure:**  
Each **CSV file** contains high-frequency trajectory data, formatted as follows (d.p. = decimal place): 

| **Dataset Column Name**      | **Format / Units**            | **Data Type** | **Explanation**                                                                 |
|--------------------------|---------------------------|-----------|-----------------------------------------------------------------------------|
| `Vehicle_ID`             | 1, 2, …                 | Integer   | Unique vehicle identifier within each CSV file                               |
| `Local_Time`             | `hh:mm:ss.sss`            | String    | Local Korean time (GMT+9) in ISO 8601 format                                 |
| `Drone_ID`               | 1, 2, …, 10             | Integer   | Unique identifier for the drone capturing the data                          |
| `Ortho_X`, `Ortho_Y`     | px (1 d.p.)               | Float     | Vehicle center coordinates in the orthophoto cut-out image                   |
| `Local_X`, `Local_Y`     | m (2 d.p.)                | Float     | KGD2002 / Central Belt 2010 planar coordinates (EPSG:5186)                  |
| `Latitude`, `Longitude`  | ° DD (7 d.p.)             | Float     | WGS84 geographic coordinates in decimal degrees (EPSG:4326)                 |
| `Vehicle_Length*`, `Vehicle_Width*` | m (2 d.p.)    | Float     | Estimated physical dimensions of the vehicle                                 |
| `Vehicle_Class`          | Categorical (0–3)          | Integer   | Vehicle type: 0 (car/van), 1 (bus), 2 (truck), 3 (motorcycle)                |
| `Vehicle_Speed*`         | km/h (1 d.p.)             | Float     | Estimated speed computed from trajectory data using Gaussian smoothing       |
| `Vehicle_Acceleration*`  | m/s² (2 d.p.)             | Float     | Estimated acceleration derived from smoothed speed values                    |
| `Road_Section*`          | `N_G`                     | String    | Road section identifier (N = node, G = lane group)                          |
| `Lane_Number*`           | 1, 2, …                 | Integer   | Lane position (1 = leftmost lane in the direction of travel)                 |
| `Visibility`             | 0/1                       | Boolean   | 1 = fully visible, 0 = partially visible in the camera frame                 |

\* These columns may be empty under certain conditions, see [[1]](https://arxiv.org/abs/2411.02136) for more details.

#### **2. Orthophoto Cut-Outs (orthophotos.zip, 1.8 GB)**
For each intersection, we provide the high-resolution orthophoto cut-outs that were used for georeferencing. These **8000×8000 pixel PNG images** cover specific areas, allowing users to overlay orthophoto trajectories within the road network.  

```
orthophotos/
│── A.png
│── B.png
│── …
└── U.png
```

For more details on the orthophoto generation process, refer to [[1]](https://arxiv.org/abs/2411.02136).

#### **3. Orthophoto Segmentations (segmentations.zip, 24.9 KB)**
We provide the road and lane segmentations for each orthophoto cut-out, stored as CSV files where each row defines a **lane polygon** within a **road section**.  

Each section (`N_G`) groups lanes moving in the same direction, with lanes numbered sequentially from the innermost outward. The CSV files are structured as follows:

```
segmentations/
│── A.csv
│── B.csv
│── …
└── U.csv
```

Each file contains the following columns:

- **`Section`**: Road section ID (`N_G` format).  
- **`Lane`**: Lane number within the section.  
- **`tlx, tly`**, **`blx, bly`**, **`brx, bry`**, **`trx, try`**: Polygon corner coordinates.  

These segmentations enabled trajectory points to be mapped to specific lanes and sections in our trajectory dataset. Vehicles outside segmented areas (e.g., intersection centers) remain unlabeled. Perspective distortions may also cause misalignments for taller vehicles.  

#### **4. Sample Videos (sample_videos.zip, 26.8 GB)**

The dataset includes **29 video samples**, each capturing the first **60 seconds of drone hovering** over its designated intersection during the final session (PM5) on **October 7, 2022**. These high-resolution 4K videos provide additional context for trajectory analysis and visualization, complementing the orthophoto cut-outs and segmentations.  

```
sample_videos/
│── A_D1_2022-10-07_PM5_60s.mp4
│── A_D2_2022-10-07_PM5_60s.mp4
│── B_D1_2022-10-07_PM5_60s.mp4
│── …
└── U_D10_2022-10-07_PM5_60s.mp4
```

#### Additional Files
   - `README.md` – Dataset documentation (this file)
   - `LICENSE.txt` – Creative Commons Attribution 4.0 License

## **Known Dataset Artifacts and Limitations**
While this dataset is designed for high accuracy, users should be aware of the following known artifacts and limitations:

- **Trajectory Fragmentation:** Trajectories may be fragmented for motorcycles in complex road infrastructure scenarios (pedestrian crossings, bicycle lanes, traffic signals) and for certain underrepresented truck variants. Additional fragmentations occurred when drones experienced technical issues during hovering, necessitating mid-recording splits that naturally resulted in divided trajectories.
- **Vehicle ID Ambiguities:** The largest `Vehicle_ID` in a CSV file does not necessarily indicate the total number of unique vehicles.
- **Kinematic Estimation Limitations:** Speed and acceleration values are derived from raw tracking data and may be affected by minor errors due to detection inaccuracies, stabilization artifacts, and applied interpolation and smoothing techniques.
- **Vehicle Dimension Estimation:** Estimates may be unreliable for stationary or non-axially moving vehicles and can be affected by bounding box overestimations capturing protruding vehicle parts or shadows.
- **Lane and Section Assignment Inaccuracies:** Perspective effects may cause vehicles with significant heights, such as trucks or buses, to be misassigned to incorrect lanes or sections in the orthophoto.
- **Occasional pedestrian pair misclassifications:** Rarely, two pedestrians walking side by side may be briefly mistaken for a motorcycle, but such instances are short-lived and typically removed by the short trajectory filter.

For a comprehensive discussion of dataset limitations and validation procedures, refer to **[[1]](https://arxiv.org/abs/2411.02136)**.  

## **Citation & Attribution**  

### **Preferred Citation:**
If you use **Songdo Traffic** in your work, please cite our accompanying manuscript **[[1]](https://arxiv.org/abs/2411.02136)**:  

> **Robert Fonod, Haechan Cho, Hwasoo Yeo, Nikolas Geroliminis** (2025).  
> *Advanced computer vision for extracting georeferenced vehicle trajectories from drone imagery*, arXiv preprint [arXiv:2411.02136](https://arxiv.org/abs/2411.02136).  
>  
> *(Note: This manuscript shall be replaced by the published version once available.)* 
>
><details>
>  <summary><b>BibTeX</b></summary>
>
>  ```bibtex
>  @article{fonod2025advanced,
>    title={Advanced computer vision for extracting georeferenced vehicle trajectories from drone imagery},
>    author={Robert Fonod and Haechan Cho and Hwasoo Yeo and Nikolas Geroliminis},
>    journal={arXiv preprint arXiv:2411.02136},
>    year={2025},
>    eprint={2411.02136},
>    archivePrefix={arXiv},
>    primaryClass={cs.CV},
>    url={https://arxiv.org/abs/2411.02136}
>  }
>  ```
> </details>
  
**Note:** Although Zenodo automatically provides a formal dataset citation (shown below), we kindly request that you reference the manuscript as the primary source of this work.

### **Dataset Citation (for archival purposes):**  
> **Robert Fonod, Haechan Cho, Hwasoo Yeo, Nikolas Geroliminis** (2025).
> *Songdo Traffic: High Accuracy Georeferenced Vehicle Trajectories from a Large-Scale Study in a Smart City* (v1). Zenodo. DOI: [10.5281/zenodo.13828384](https://doi.org/10.5281/zenodo.13828384).