"""Deterministic, causal trajectory replay and out-of-site evaluation."""
from pathlib import Path
import sys, json, hashlib, time
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'; CACHE=ROOT/'cache'; RES=ROOT/'results'
CACHE.mkdir(exist_ok=True); RES.mkdir(exist_ok=True)
GRID=np.arange(1,31)*.1
EPS=np.array([.5,1.,2.])
SITES=list('ABCEFGHIJKLMNOPQRSTU')
MODELS=['PH','CV','CA','CTRV']
VARIANTS=['primary','history05','history15','stride2','state075','state125','visible','offset025','offset05']

def states(v,a,scale=1.):
    speed=np.linalg.norm(v,axis=1)
    omega=(v[:,0]*a[:,1]-v[:,1]*a[:,0])/np.maximum(speed**2,1e-10)
    lon=np.sum(v*a,axis=1)/np.maximum(speed,1e-5)
    s=np.full(len(v),3,dtype=np.int8)
    s[np.abs(lon)>=scale]=2
    s[np.abs(omega)>=.15*scale]=1
    s[speed<scale]=0
    return s,omega

def fits(t,p,idx,h):
    u=t[idx]
    desired=u[:,None]+np.arange(-round(h*10),1)[None,:]*.1
    hi=np.searchsorted(t,desired+1e-8,side='right')-1
    assert hi.min()>=0 and np.all(hi<=idx[:,None])
    s=t[hi]-u[:,None]
    y=p[hi]-p[idx,None,:]
    v=np.sum(s[:,:,None]*y,axis=1)/np.sum(s*s,axis=1)[:,None]
    x=np.stack([s,.5*s*s],axis=2)
    coef=np.linalg.solve(np.einsum('nki,nkj->nij',x,x),np.einsum('nki,nkj->nij',x,y))
    return v,coef[:,0],coef[:,1],hi

def first_cross(err,valid):
    hit=(err[:,:,None]>EPS[None,None,:]) & valid[:,:,None]
    return np.where(hit.any(axis=1),hit.argmax(axis=1)+1,31).astype(np.uint8)

def process(path):
    key=path.stem
    dest=CACHE/(key+'.npz'); qdest=CACHE/(key+'.json')
    if dest.exists() and qdest.exists(): return
    cols=['Vehicle_ID','Local_Time','Local_X','Local_Y','Vehicle_Class','Visibility']
    df=pd.read_csv(path,usecols=cols)
    q={'file':path.name,'raw_rows':len(df),'noncar_rows':int((df.Vehicle_Class!=0).sum())}
    df=df[df.Vehicle_Class==0].copy()
    df['time']=pd.to_timedelta(df.Local_Time).dt.total_seconds()
    good=np.isfinite(df[['time','Local_X','Local_Y']]).all(axis=1)
    q['nonfinite_rows']=int((~good).sum()); df=df[good]
    q['duplicate_rows']=int(df.duplicated().sum());df=df.drop_duplicates()
    collision=df.duplicated(['Vehicle_ID','time'],keep=False)
    q['conflict_rows']=int(collision.sum());df=df[~collision]
    df=df.sort_values(['Vehicle_ID','time'])
    q['raw_ids']=int(df.Vehicle_ID.nunique());q['retained_car_rows']=len(df)
    q['center_x']=float(df.Local_X.median());q['center_y']=float(df.Local_Y.median())
    q['min_time']=float(df.time.min());q['max_time']=float(df.time.max())
    q['jump_boundaries']=0;q['gap_boundaries']=0;q['fragments']=0
    coll={k:[] for k in ['track','t0','nfollow','state','state075','state125','visible','ordinal','first','first05','first15','state05','state15','offset025','offset05','err1','err3']}
    sums=np.zeros((4,30)); nfull=0; fragid=0
    for _,d in df.groupby('Vehicle_ID',sort=False):
        t=d.time.to_numpy();p=d[['Local_X','Local_Y']].to_numpy();vis=d.Visibility.to_numpy()
        dt=np.diff(t);jump=np.linalg.norm(np.diff(p,axis=0),axis=1)>50*np.maximum(dt,1e-9)
        gap=(dt>.100001)|(dt<=0)
        q['jump_boundaries']+=int(jump.sum());q['gap_boundaries']+=int(gap.sum())
        cuts=np.r_[0,np.flatnonzero(jump|gap)+1,len(t)]
        for lo,hi in zip(cuts[:-1],cuts[1:]):
            fragid+=1;q['fragments']+=1
            tt=t[lo:hi];pp=p[lo:hi];vv=vis[lo:hi]
            if tt[-1]-tt[0]<1.6:continue
            # All history sensitivities share origins with >=1.5 s past.
            ix=np.searchsorted(tt,np.arange(tt[0]+1.5,tt[-1]-.1+1e-7,1.))
            ix=np.unique(ix[ix<len(tt)])
            if not len(ix):continue
            u=tt[ix];valid=u[:,None]+GRID<=tt[-1]+1e-7
            keep=valid[:,0];ix=ix[keep];u=u[keep];valid=valid[keep]
            if not len(ix):continue
            pp=pp-pp[0]
            fut=np.stack([np.interp((u[:,None]+GRID).ravel(),tt,pp[:,k]).reshape(len(ix),30) for k in range(2)],axis=2)-pp[ix,None,:]
            cv,cv2,a,hidx=fits(tt,pp,ix,1.)
            state,w=states(cv2,a);sp=np.linalg.norm(cv2,axis=1)
            theta=np.arctan2(cv2[:,1],cv2[:,0]);z=w[:,None]*GRID
            fac=np.sinc(z/(2*np.pi));ctrv=sp[:,None,None]*GRID[None,:,None]*fac[:,:,None]*np.stack([np.cos(theta[:,None]+z/2),np.sin(theta[:,None]+z/2)],axis=2)
            pred=np.stack([np.zeros_like(fut),cv[:,None,:]*GRID[None,:,None],cv2[:,None,:]*GRID[None,:,None]+.5*a[:,None,:]*GRID[None,:,None]**2,ctrv],axis=1)
            err=np.linalg.norm(pred-fut[:,None,:,:],axis=3)
            fc=np.stack([first_cross(err[:,m],valid) for m in range(4)],axis=1)
            full=valid[:,-1];sums+=err[full].sum(axis=0);nfull+=int(full.sum())
            extra={}
            for h,tag in [(.5,'05'),(1.5,'15')]:
                v_h,v2_h,a_h,_=fits(tt,pp,ix,h)
                extra['first'+tag]=first_cross(np.linalg.norm(v_h[:,None,:]*GRID[None,:,None]-fut,axis=2),valid)
                extra['state'+tag]=states(v2_h,a_h)[0]
            for offset,tag in [(.25,'025'),(.5,'05')]:
                # Sensitivity perturbation, not observed localization error.
                bias=np.column_stack([np.full(len(ix),offset),np.zeros(len(ix))])
                extra['offset'+tag]=first_cross(np.linalg.norm(pred[:,1]+bias[:,None,:]-fut,axis=2),valid)
            vals=dict(track=np.full(len(ix),fragid,np.int32),t0=u,nfollow=valid.sum(axis=1).astype(np.uint8),state=state,state075=states(cv2,a,.75)[0],state125=states(cv2,a,1.25)[0],visible=(vv[hidx]==1).all(axis=1),ordinal=np.arange(len(ix),dtype=np.int16),first=fc,err1=err[:,:,9].astype(np.float32),err3=np.where(full[:,None],err[:,:,29],np.nan).astype(np.float32),**extra)
            for k,v in vals.items():coll[k].append(v)
    arrays={k:np.concatenate(v) for k,v in coll.items()}
    arrays['error_sums']=sums;arrays['nfull']=np.array(nfull)
    q['origins']=len(arrays['state']);q['contributing_fragments']=int(len(np.unique(arrays['track'])));q['full_origins']=nfull
    qdest.write_text(json.dumps(q,indent=2),encoding='utf-8');np.savez_compressed(dest,**arrays)
    print('PROCESSED',key,q['raw_rows'],q['origins'],flush=True)

def load_all():
    datasets=[];quality=[]
    for date in ['2022-10-04','2022-10-07']:
        for site in SITES:
            for period in ['AM1','PM1']:
                key=f'{date}_{site}_{period}'
                file=RAW/(key+'.csv');prov=RAW/(key+'.csv.provenance.json')
                if not prov.exists():raise FileNotFoundError(prov)
                process(file)
                ar=dict(np.load(CACHE/(key+'.npz')))
                ar.update(date=date,site=site,period=period)
                datasets.append(ar);quality.append(json.loads((CACHE/(key+'.json')).read_text()))
    pd.DataFrame(quality).to_csv(RES/'quality.csv',index=False)
    return datasets,quality

def sample(ar,variant,model=1,epsidx=1):
    state=ar['state'];first=ar['first'][:,model,epsidx];mask=np.ones(len(state),bool)
    if variant=='history05':first=ar['first05'][:,epsidx];state=ar['state05']
    if variant=='history15':first=ar['first15'][:,epsidx];state=ar['state15']
    if variant=='stride2':mask=ar['ordinal']%2==0
    if variant=='state075':state=ar['state075']
    if variant=='state125':state=ar['state125']
    if variant=='visible':mask=ar['visible']
    if variant=='offset025':first=ar['offset025'][:,epsidx]
    if variant=='offset05':first=ar['offset05'][:,epsidx]
    return state[mask],first[mask],ar['nfollow'][mask]

def curves(dataset,variant,model,epsidx,complete_only=False):
    out={};samples={}
    for site in SITES:
        values=[sample(a,variant,model,epsidx) for a in dataset if a['site']==site]
        state,first,nf=[np.concatenate([v[k] for v in values]) for k in range(3)]
        if complete_only:
            mask=nf==30;state=state[mask];first=first[mask];nf=nf[mask]
        samples[site]=(state,first,nf)
        fail=first[:,None]<=np.arange(1,31)
        unknown=(nf[:,None]<np.arange(1,31))&~fail
        risks=[];counts=[]
        for g in [-1,0,1,2,3]:
            m=np.ones(len(state),bool) if g==-1 else state==g
            risks.append((fail[m]|unknown[m]).mean(axis=0) if m.any() else np.full(30,np.nan));counts.append(int(m.sum()))
        out[site]=(np.array(risks),np.array(counts))
    return out,samples

def calibrate(cs,held,rule):
    mats=np.array([v[0] for s,v in cs.items() if s!=held]);counts=np.array([v[1] for s,v in cs.items() if s!=held])
    pooled=np.nanmean(mats,axis=0)
    global_idx=np.flatnonzero(pooled[0]<=.05+1e-12)
    tau_global=int(global_idx[-1]+1) if len(global_idx) else 0
    if rule=='global':return np.full(4,tau_global,dtype=int)
    taus=[]
    for g in range(1,5):
        valid=counts[:,g]>=30
        if valid.sum()<10:taus.append(tau_global);continue
        risk=np.nanmean(mats[valid,g],axis=0) if rule=='state' else np.max(mats[valid,g],axis=0)
        ok=np.flatnonzero(risk<=.05+1e-12);taus.append(int(ok[-1]+1) if len(ok) else 0)
    return np.array(taus)

def metrics(state,first,nf,taus):
    tt=taus[state];fail=first<=tt;unknown=(nf<tt)&~fail
    return {'n':len(tt),'mean_tau':float(tt.mean()/10),'lower':float(fail.mean()),'upper':float((fail|unknown).mean()),'unknown':float(unknown.mean()),'positive':float((tt>0).mean()),'failures':int(fail.sum()),'unknown_n':int(unknown.sum())}

def evaluate(data):
    cal=[a for a in data if a['date']=='2022-10-04'];test=[a for a in data if a['date']=='2022-10-07']
    rows=[];rules=[]
    configurations=[('primary',m,e) for m in range(4) for e in range(3)]+[(v,1,1) for v in VARIANTS[1:]]
    for variant,model,ei in configurations:
        cc,_=curves(cal,variant,model,ei);_,ts=curves(test,variant,model,ei)
        for site in SITES:
            for rule in ['global','state','worst_site']:
                taus=calibrate(cc,site,rule)
                rules.append(dict(variant=variant,model=MODELS[model],epsilon=EPS[ei],site=site,rule=rule,**{f'tau_{g}':taus[g]/10 for g in range(4)}))
                state,first,nf=ts[site]
                for population in ['all','full']:
                    mask=np.ones(len(state),bool) if population=='all' else nf==30
                    rows.append(dict(variant=variant,model=MODELS[model],epsilon=EPS[ei],site=site,rule=rule,population=population,**metrics(state[mask],first[mask],nf[mask],taus)))
    result=pd.DataFrame(rows);result.to_csv(RES/'site_metrics.csv',index=False);pd.DataFrame(rules).to_csv(RES/'rules.csv',index=False)
    rng=np.random.default_rng(20260914);boot=rng.integers(0,20,(2000,20))
    summaries=[]
    for keys,group in result.groupby(['variant','model','epsilon','rule','population'],sort=False):
        group=group.sort_values('site');summary=dict(zip(['variant','model','epsilon','rule','population'],keys))
        for metric in ['mean_tau','lower','upper','unknown','positive']:
            v=group[metric].to_numpy();ci=np.quantile(v[boot].mean(axis=1),[.025,.975])
            summary[metric]=v.mean();summary[metric+'_lo']=ci[0];summary[metric+'_hi']=ci[1]
        summary['sites_upper_le05']=int((group.upper<=.05).sum());summary['worst_upper']=group.upper.max();summary['best_upper']=group.upper.min();summary['n']=int(group.n.sum())
        summaries.append(summary)
    pd.DataFrame(summaries).to_csv(RES/'summary.csv',index=False)
    pairs=[]
    for pop in ['all','full']:
        b=result[(result.variant=='primary')&(result.model=='CV')&(result.epsilon==1)&(result.population==pop)]
        for rule in ['state','worst_site']:
            a=b[b.rule==rule].sort_values('site');g=b[b.rule=='global'].sort_values('site')
            for metric in ['mean_tau','lower','upper']:
                v=a[metric].to_numpy()-g[metric].to_numpy();ci=np.quantile(v[boot].mean(axis=1),[.025,.975])
                pairs.append(dict(population=pop,rule=rule,metric=metric,difference=v.mean(),lo=ci[0],hi=ci[1]))
    pd.DataFrame(pairs).to_csv(RES/'paired.csv',index=False)
    # Complete-only calibration is an explicitly separate ablation.
    cc,_=curves(cal,'primary',1,1,True);_,ts=curves(test,'primary',1,1)
    abl=[]
    for site in SITES:
        for rule in ['global','state','worst_site']:
            tau=calibrate(cc,site,rule);s,f,n=ts[site]
            abl.append(dict(site=site,rule=rule,**metrics(s,f,n,tau)))
    pd.DataFrame(abl).to_csv(RES/'complete_calibration_ablation.csv',index=False)
    # Full-follow-up prediction errors use the same origins in all models.
    er=[];cur=[]
    for site in SITES:
        aa=[a for a in test if a['site']==site]
        for m in range(4):
            for h in [1,3]:
                vals=np.concatenate([a[f'err{h}'][a['nfollow']==30,m] for a in aa])
                er.append(dict(site=site,model=MODELS[m],horizon=h,n=len(vals),mean=float(vals.mean()),median=float(np.median(vals)),p95=float(np.quantile(vals,.95))))
            sumerr=sum(a['error_sums'][m] for a in aa);nn=sum(int(a['nfull']) for a in aa)
            for t,v in zip(GRID,sumerr/nn):cur.append(dict(site=site,model=MODELS[m],horizon=t,mean=v))
    pd.DataFrame(er).to_csv(RES/'errors.csv',index=False);pd.DataFrame(cur).to_csv(RES/'error_curves.csv',index=False)
    # State counts and test subgroup risk, using each site's own held-out rule.
    sr=[]
    cc,_=curves(cal,'primary',1,1);_,ts=curves(test,'primary',1,1)
    for site in SITES:
        s,f,n=ts[site]
        for rule in ['global','state','worst_site']:
            tau=calibrate(cc,site,rule)
            for g in range(4):
                mask=s==g
                if mask.any():sr.append(dict(site=site,rule=rule,state=g,**metrics(s[mask],f[mask],n[mask],tau)))
    pd.DataFrame(sr).to_csv(RES/'state_metrics.csv',index=False)

def validate():
    t=np.arange(0,10,.02);p=np.column_stack([3*t+.5*t*t,-2*t+.2*t*t]);ix=np.array([100,200,300])
    _,v,a,hi=fits(t,p,ix,1.)
    assert np.allclose(a,[1.,.4]) and np.allclose(v,np.column_stack([3+t[ix],-2+.4*t[ix]]))
    assert np.all(hi<=ix[:,None])
    e=np.array([[0.,1.2,.2]+[0.]*27]);vld=np.ones((1,30),bool)
    assert first_cross(e,vld)[0,1]==2
    x=metrics(np.array([0,0,0]),np.array([2,31,31]),np.array([30,1,30]),np.array([3]*4))
    assert np.isclose(x['lower'],1/3) and np.isclose(x['upper'],2/3)
    (RES/'validation.json').write_text(json.dumps({'ca_polynomial_identity':True,'causal_history':True,'first_exceedance_no_recovery':True,'unknown_bounds_identity':True,'note':'Synthetic arrays are numerical unit checks only; not study observations.'},indent=2))

if __name__=='__main__':
    validate()
    if '--available' in sys.argv:
        for path in sorted(RAW.glob('*.csv')):
            if path.with_suffix('.csv.provenance.json').exists():process(path)
    else:
        data,q=load_all();evaluate(data);print('ANALYSIS COMPLETE',sum(z['origins'] for z in q),flush=True)
