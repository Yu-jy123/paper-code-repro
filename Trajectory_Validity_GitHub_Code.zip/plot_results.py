from pathlib import Path
import os
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'trajectory_paper'/'packages'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.mplconfig')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=ROOT/'results';F=ROOT/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,'savefig.dpi':300,'pdf.fonttype':42})
COLORS=['#69737C','#187AA0','#BF6338','#4D8A64']
def save(fig,name):
    fig.tight_layout();fig.savefig(F/(name+'.png'),bbox_inches='tight');fig.savefig(F/(name+'.pdf'),bbox_inches='tight');plt.close(fig)
q=pd.read_csv(R/'quality.csv');q['site']=q.file.str.split('_').str[1];q['date']=q.file.str[:10]
sites=sorted(q.site.unique())
fig,ax=plt.subplots(1,2,figsize=(10,4.2))
cent=q.groupby('site')[['center_x','center_y']].median();cent-=cent.min()
ax[0].scatter(cent.center_x/1000,cent.center_y/1000,s=40,color=COLORS[1])
for site,row in cent.iterrows():ax[0].annotate(site,(row.center_x/1000,row.center_y/1000),xytext=(4,4),textcoords='offset points')
ax[0].set(xlabel='Relative easting (km)',ylabel='Relative northing (km)',title='(a) Approximate observation-area locations');ax[0].set_aspect('equal')
x=np.arange(20)
for i,date in enumerate(['2022-10-04','2022-10-07']):
    vals=q[q.date==date].groupby('site').origins.sum().reindex(sites)
    ax[1].bar(x+(i-.5)*.38,vals/1000,.38,label=date,color=COLORS[i])
ax[1].set_xticks(x,sites);ax[1].set(xlabel='Intersection',ylabel='Replay origins (thousands)',title='(b) Calibration and test sample sizes');ax[1].legend(frameon=False,fontsize=8)
save(fig,'fig1_sites')
c=pd.read_csv(R/'error_curves.csv')
fig,ax=plt.subplots(1,2,figsize=(10,3.8))
for m,(model,g) in enumerate(c.groupby('model',sort=False)):
    v=g.pivot(index='site',columns='horizon',values='mean');xx=v.columns.to_numpy()
    for a in ax:a.plot(xx,v.mean(),label=model,color=COLORS[m]);a.fill_between(xx,v.quantile(.25),v.quantile(.75),alpha=.10,color=COLORS[m])
ax[0].set(xlabel='Information age (s)',ylabel='Mean position error (m)',title='(a) All four predictors')
ax[1].set(xlabel='Information age (s)',ylabel='Mean position error (m)',title='(b) Short-horizon detail',xlim=(0,1),ylim=(0,3))
ax[0].legend(frameon=False);save(fig,'fig2_errors')
s=pd.read_csv(R/'site_metrics.csv');b=s[(s.variant=='primary')&(s.model=='CV')&(s.epsilon==1)&(s.population=='all')]
labels={'global':'Global','state':'State-specific','worst_site':'Worst-site state'}
fig,ax=plt.subplots(2,1,figsize=(10,6),sharex=True)
for j,rule in enumerate(labels):
    v=b[b.rule==rule].set_index('site').loc[sites]
    ax[0].plot(x,v.mean_tau,'o-',ms=4,label=labels[rule],color=COLORS[j])
    ax[1].vlines(x+(j-1)*.15,100*v.lower,100*v.upper,color=COLORS[j],lw=2)
    ax[1].scatter(x+(j-1)*.15,100*v.upper,s=17,color=COLORS[j])
ax[0].set(ylabel='Mean validity horizon (s)');ax[0].legend(frameon=False,ncol=3)
ax[1].axhline(5,color='#A33636',ls='--',lw=1);ax[1].set(ylabel='Exceedance bounds (%)',xlabel='Held-out intersection');ax[1].set_xticks(x,sites)
save(fig,'fig3_site_results')
summary=pd.read_csv(R/'summary.csv');b=summary[(summary.variant=='primary')&(summary.model=='CV')&(summary.population=='all')]
fig,ax=plt.subplots(figsize=(7.4,4))
for j,rule in enumerate(labels):
    v=b[b.rule==rule].sort_values('epsilon')
    ax.plot(v.mean_tau,100*v.upper,'o-',color=COLORS[j],label=labels[rule])
    for _,row in v.iterrows():ax.annotate(f'{row.epsilon:g} m',(row.mean_tau,row.upper*100),xytext=(4,5),textcoords='offset points',fontsize=8)
ax.axhline(5,color='#A33636',ls='--',lw=1);ax.set(xlabel='Site-equal mean validity horizon (s)',ylabel='Site-equal upper exceedance bound (%)');ax.legend(frameon=False);save(fig,'fig4_thresholds')
variant_names={'primary':'Primary','history05':'History 0.5 s','history15':'History 1.5 s','stride2':'Origin spacing 2 s','state075':'State thresholds x0.75','state125':'State thresholds x1.25','visible':'Visible history only','offset025':'Position offset 0.25 m','offset05':'Position offset 0.5 m'}
fig,ax=plt.subplots(1,2,figsize=(10,5.2),sharey=True)
y=np.arange(len(variant_names))
for j,rule in enumerate(labels):
    v=summary[(summary.model=='CV')&(summary.epsilon==1)&(summary.population=='all')&(summary.rule==rule)].set_index('variant').loc[list(variant_names)]
    ax[0].plot(v.mean_tau,y,'o-',color=COLORS[j],ms=4,label=labels[rule]);ax[1].plot(v.upper*100,y,'o-',color=COLORS[j],ms=4)
ax[0].set_yticks(y,list(variant_names.values()));ax[0].invert_yaxis();ax[0].set_xlabel('Mean validity horizon (s)');ax[1].set_xlabel('Upper exceedance bound (%)');ax[1].axvline(5,color='#A33636',ls='--',lw=1);ax[0].legend(frameon=False,fontsize=8,loc='lower left',bbox_to_anchor=(0,1.02),ncol=3)
save(fig,'fig5_sensitivity')
print('FIGURES COMPLETE',flush=True)
