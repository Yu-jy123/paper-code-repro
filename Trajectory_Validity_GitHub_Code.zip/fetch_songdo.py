from __future__ import annotations

import hashlib
import json
import sys
import urllib.request
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "packages"))

import requests
from remotezip import RemoteZip


RECORD_ID = "13828384"
DATES = ["2022-10-04", "2022-10-07"]
SESSIONS = ["AM1", "PM1"]
SITES = ["A", "B", "C", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U"]
RAW = ROOT / "raw"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    metadata_url = f"https://zenodo.org/api/records/{RECORD_ID}"
    session = requests.Session()
    session.proxies.update(urllib.request.getproxies())
    meta_path = RAW / "zenodo_record_13828384.json"
    if meta_path.exists():
        metadata = json.loads(meta_path.read_text(encoding="utf-8"))
    else:
        response = session.get(metadata_url, timeout=60)
        response.raise_for_status()
        metadata = response.json()
    (RAW / "zenodo_record_13828384.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    zenodo_files = {item["key"]: item for item in metadata["files"]}

    def fetch_one(job):
        date, site, period = job
        zip_name = f"{date}_{site}.zip"
        item = zenodo_files[zip_name]
        url = item["links"].get("content", item["links"].get("self"))
        out = RAW / f"{date}_{site}_{period}.csv"
        provenance = out.with_suffix(out.suffix + ".provenance.json")
        if out.exists() and provenance.exists() and sha256(out) == json.loads(provenance.read_text())["local_sha256"]:
            print(f"cached {out.name} {out.stat().st_size}")
            return True
        print(f"reading {zip_name}", flush=True)
        for attempt in range(4):
            try:
                with requests.Session() as worker_session:
                    worker_session.proxies.update(urllib.request.getproxies())
                    with RemoteZip(url, session=worker_session, timeout=120) as rz:
                        members = [n for n in rz.namelist() if n.endswith(f"_{period}.csv")]
                        if len(members) != 1:
                            raise RuntimeError(f"Expected one CSV in {zip_name}, found {members}")
                        member_info = rz.getinfo(members[0])
                        with rz.open(members[0]) as src, out.with_suffix(".partial").open("wb") as dst:
                            for block in iter(lambda: src.read(1024 * 1024), b""):
                                dst.write(block)
                assert out.with_suffix(".partial").stat().st_size == member_info.file_size
                out.with_suffix(".partial").replace(out)
                break
            except Exception as e:
                print(f"retry {out.name} {attempt} {e}", flush=True)
                if attempt == 3:
                    return False
                time.sleep(2)
        prov = {
            "dataset": "Songdo Traffic v1",
            "record_id": RECORD_ID,
            "dataset_doi": "10.5281/zenodo.13828384",
            "archive": zip_name,
            "archive_md5": item["checksum"],
            "archive_url": url,
            "member": members[0],
            "retrieved_utc": datetime.now(timezone.utc).isoformat(),
            "local_sha256": sha256(out),
            "local_size_bytes": out.stat().st_size,
        }
        (out.with_suffix(out.suffix + ".provenance.json")).write_text(
            json.dumps(prov, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"saved {out.name} {out.stat().st_size}", flush=True)
        return True

    jobs = [(date, site, period) for date in DATES for period in SESSIONS for site in SITES]
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(fetch_one, jobs))
    print(f"COMPLETE {sum(results)}/{len(results)}", flush=True)
    if not all(results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
